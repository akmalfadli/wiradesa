Ini hanya contoh
