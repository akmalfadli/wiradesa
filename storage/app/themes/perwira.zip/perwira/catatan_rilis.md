Catatan Rilis v25.8:

Ini adalah tema Perwira yang dibuat untuk aplikasi Sistem Informasi Desa OpenSID

### BUG :

1. Perbaikan menu versi mobile.
2. Perbaikan sebutan dusun pada halaman DPT.
3. Perbaikan widget statistik pengunjung.

### TEKNIS :

1. Penyesuaian halaman statis.
2. Penyesuaian halaman 404.
3. Penyesuaian judul halaman statistik.
