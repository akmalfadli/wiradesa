{{-- resources/views/partials/hero.blade.php --}}
@php
    $bg_header = $latar_website;
@endphp
<div class="relative h-[300px] md:h-[400px] bg-green-700 text-white overflow-hidden">
    {{-- background --}}
    <div class="absolute inset-0 bg-cover bg-center opacity-50" 
         style="background-image: url({{ $bg_header }});">
    </div>
    
    {{-- hero content --}}
    <div class="relative z-10 h-full flex">
        {{-- Left side - Main content --}}
        <div class="flex-1 flex flex-col justify-center ml-8">
            <h1 class="text-3xl md:text-4xl lg:text-5xl font-bold mb-2">
                Website Resmi
            </h1>
            <h2 class="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
                {{ ucfirst(setting('sebutan_desa')) }} {{ ucwords($desa['nama_desa']) }}
            </h2>
            <p class="text-sm">{{ ucfirst(setting('sebutan_kecamatan')) }} {{ ucwords($desa['nama_kecamatan']) }} 
                {{ ucfirst(setting('sebutan_kabupaten')) }} {{ ucwords($desa['nama_kabupaten']) }}</p>
            <p class="text-sm">Provinsi {{ ucwords($desa['nama_propinsi']) }}</p>
        </div>

        {{-- Right side - Digital Clock --}}
        <div class="flex flex-col justify-center items-center mr-8 min-w-[200px]">
            <div class="bg-black bg-opacity-5 backdrop-blur-xs rounded-lg p-4">
                <div class="text-left">
                    <div id="digital-clock" class="text-2xl md:text-3xl font-mono font-bold mb-1">
                        00:00:00
                    </div>
                    <div id="digital-date" class="text-xs md:text-sm opacity-90 mb-2">
                        Loading...
                    </div>
                    <div id="working-hours" class="text-xs opacity-80">
                        {{-- Working hours for current day will be inserted here by JavaScript --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    @if ($teks_berjalan)
        <div class="absolute bottom-0 left-0 right-0 bg-white bg-opacity-20 py-1.5 text-xs z-20">
            <marquee onmouseover="this.stop();" onmouseout="this.start();" class="block">
                @foreach ($teks_berjalan as $marquee)
                    <span class="px-3">
                        {{ $marquee['teks'] }}
                        @if (trim($marquee['tautan']) && $marquee['judul_tautan'])
                            <a href="{{ $marquee['tautan'] }}" class="hover:text-link">{{ $marquee['judul_tautan'] }}</a>
                        @endif
                    </span>
                @endforeach
            </marquee>
        </div>
    @endif
</div>

{{-- Pass working hours data to JavaScript --}}
<script>
// Working hours data from PHP
const workingHoursData = @json($jam_kerja ?? []);

function updateClock() {
    const now = new Date();
    
    // Format time (24-hour format)
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const timeString = `${hours}:${minutes}:${seconds}`;
    
    // Format date
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric'
    };
    const dateString = now.toLocaleDateString('id-ID', options);
    
    // Get current day name in Indonesian
    const dayNames = {
        'Sunday': 'Minggu',
        'Monday': 'Senin', 
        'Tuesday': 'Selasa',
        'Wednesday': 'Rabu',
        'Thursday': 'Kamis',
        'Friday': 'Jumat',
        'Saturday': 'Sabtu'
    };
    
    const currentDay = now.toLocaleDateString('en-US', { weekday: 'long' });
    const currentDayIndo = dayNames[currentDay];
    
    // Find working hours for current day
    let workingHoursText = '';
    if (workingHoursData && workingHoursData.length > 0) {
        const todaySchedule = workingHoursData.find(schedule => 
            schedule.nama_hari.toLowerCase() === currentDayIndo.toLowerCase()
        );
        
        if (todaySchedule) {
            if (todaySchedule.status) {
                workingHoursText = `${todaySchedule.jam_masuk} - ${todaySchedule.jam_keluar}`;
            } else {
                workingHoursText = 'Libur';
            }
        }
    }
    
    // Update elements
    const clockElement = document.getElementById('digital-clock');
    const dateElement = document.getElementById('digital-date');
    const workingHoursElement = document.getElementById('working-hours');
    
    if (clockElement) clockElement.textContent = timeString;
    if (dateElement) dateElement.textContent = dateString;
    if (workingHoursElement) {
    if (workingHoursText === 'Libur') {
            workingHoursElement.innerHTML =
                '<span class="bg-red-500 text-white px-2 py-0.5 rounded text-xs">Libur</span>';
        } else if (workingHoursText) {
            workingHoursElement.innerHTML =
                `<span class="bg-green-500 text-white px-2 py-0.5 rounded text-xs">Buka ${workingHoursText}</span>`;
        } else {
            workingHoursElement.textContent = '';
        }
    }

}

// Update clock immediately and then every second
updateClock();
setInterval(updateClock, 1000);
</script>