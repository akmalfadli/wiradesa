<div class="bg-white z-[9999] flex justify-center items-center">
    <div class="spinner-grow inline-block w-8 h-8 bg-primary-100 rounded-full opacity-0 mb-5" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
